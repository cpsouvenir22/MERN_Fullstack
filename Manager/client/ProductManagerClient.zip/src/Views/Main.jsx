import {useState, useEffect} from 'react';
import Axios from 'axios';
import { Link } from '@reach/router';


const Main = props => {
    const [products,setProducts] = useState (false);

    useEffect(() => {
        Axios.get("http://localhost:8000/Products")
            .then (res => setProducts(res.data.results))
            .catch(err => console.log(err))
    },[])

    return(
        products ?
            <table className="table table-hover col-6 mx">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        products.map((p,i) => {
                            return <tr key ={i}>
                                        <td>{p.title}</td>
                                        <td>{p.price}</td>
                                        <td>{p.description}</td>
                                            

                                        
                            </tr>
                        })
                    }
                </tbody>
            </table> :
            <h2>Loading</h2>
    )
}

export default Main;