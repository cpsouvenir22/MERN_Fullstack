import {useState, useEffect} from 'react';
import Axios from 'axios';

const Show = props => {
    const [product, setProduct] = useState (false);

    useEffect (()=> {
        Axios.get(`http://localhost:8000/Products/${props.id}`)
            .then(res=> setProduct (res.data.results))
            .catch(err => console.log(err))
                
                
    }, [props])

    return (
        <div className="card col-4 mx-auto">
            <div className="card-body">
                <h2 className= "card-title">{product.title}</h2>
                <h4 className= "card-title">${product.price}</h4>
                <h4 className= "card-title">{product.description}</h4>
            </div>
        </div>
    )
}

export default Show;